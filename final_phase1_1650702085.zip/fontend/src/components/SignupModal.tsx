import React, { useState } from 'react';

type Props = {
  isOpen: boolean;
  onClose: () => void;
  onSignup: (email: string) => void;
};

const SignupModal: React.FC<Props> = ({ isOpen, onClose, onSignup }) => {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validation
    if (!email.trim() || !username.trim() || !password.trim() || !confirmPassword.trim()) {
      setError('กรุณากรอกข้อมูลทั้งหมด');
      return;
    }

    if (password !== confirmPassword) {
      setError('รหัสผ่านไม่ตรงกัน');
      return;
    }

    if (password.length < 6) {
      setError('รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร');
      return;
    }

    try {
      setLoading(true);
      const resp = await fetch('http://localhost:5001/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          username: username.trim(),
          name: name.trim(),
          password,
          confirmPassword
        }),
      });

      if (!resp.ok) {
        const data = await resp.json();
        setError(data.error || 'เกิดข้อผิดพลาดในการสมัคร');
        return;
      }

      const data = await resp.json();
      // Store user info locally
      try {
        localStorage.setItem('user', JSON.stringify({ email: data.email, id: data.id }));
      } catch (e) {
        // ignore
      }
      onSignup(data.email);
    } catch (err) {
      console.error('Signup request failed', err);
      setError('ไม่สามารถติดต่อเซิร์ฟเวอร์ได้');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      <div className="relative bg-white rounded-xl shadow-2xl w-full max-w-sm p-6 z-10">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold">สมัครสมาชิก</h3>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-800 text-2xl leading-none"
            aria-label="Close"
          >
            ✕
          </button>
        </div>
        <p className="text-sm text-gray-600 mb-4">สร้างบัญชีใหม่เพื่อใช้ฟีเจอร์ถูกใจ</p>

        <form onSubmit={handleSubmit}>
          <label className="block text-sm font-medium text-gray-700">Email</label>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            className="w-full mt-1 mb-3 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#16a34a]"
            autoFocus
          />

          <label className="block text-sm font-medium text-gray-700">Username</label>
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            type="text"
            className="w-full mt-1 mb-3 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#16a34a]"
          />

          <label className="block text-sm font-medium text-gray-700">ชื่อ (ไม่บังคับ)</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            type="text"
            className="w-full mt-1 mb-3 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#16a34a]"
          />

          <label className="block text-sm font-medium text-gray-700">Password</label>
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            className="w-full mt-1 mb-3 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#16a34a]"
          />

          <label className="block text-sm font-medium text-gray-700">ยืนยันรหัสผ่าน</label>
          <input
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            type="password"
            className="w-full mt-1 mb-3 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#16a34a]"
          />

          {error && <div className="text-sm text-red-600 mb-3">{error}</div>}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2 rounded-lg bg-[#16a34a] text-white hover:bg-[#15803d] disabled:opacity-50"
          >
            {loading ? 'กำลังสมัคร...' : 'สมัครสมาชิก'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default SignupModal;
