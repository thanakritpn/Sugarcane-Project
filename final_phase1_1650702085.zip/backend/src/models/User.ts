import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  username: { type: String, required: true, unique: true, trim: true },
  name: { type: String, default: '' },
  password: { type: String, required: true }, // hashed
}, { timestamps: true });

const User = mongoose.model('User', userSchema);

export default User;
